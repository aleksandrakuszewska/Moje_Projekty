Projekt Profesjonalna Szkoła Tenisa PST - instrukcja otwarcia

1. Wymagania:
        a) Serwer XAMP z Apache i bazą danych MySQL
        b) Pliki projektu na dysku komputera
2. Instalacja:
    a) Skopiuj pliki projektu do folderu htdocs na serwerze XAMP.
    b) Za pomocą phpMyAdmin lub innego narzędzia zaimportuj z pliku klienci.sql (bazę danych z utworzonymi tabelami), dołączonego do projektu.
    c) Uruchom serwer XAMP i przetestuj stronę, powinna być dostępna pod adresem http://localhost/klienci/startowa.php.
3. Opis funkcjonalności
    a) Wszystkie funkcjonalności opisane są w pliku Sprawozdanie.pdf dołączonym do folderu projektu.
4. Uwagi
    a) Aplikacja jest tylko do celów edukacyjnych i nie powinna być używana w produkcji bez dodatkowej kontroli bezpieczeństwa i testów.
